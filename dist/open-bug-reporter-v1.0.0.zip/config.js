export const APP_CONFIG = {
  // Reemplaza por la URL real de tu Firebase Function desplegada.
  functionUrl: "https://us-central1-reporte-de-problemas-ta.cloudfunctions.net/reporteQa"
};
