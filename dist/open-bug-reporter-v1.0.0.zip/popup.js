import { APP_CONFIG } from "./config.js";

const form = document.getElementById("qa-form");
const reporterInput = document.getElementById("reporter");
const comentarioInput = document.getElementById("comentario");
const pasosInput = document.getElementById("pasos");
const startBtn = document.getElementById("start-btn");
const status = document.getElementById("status");

chrome.storage.local.get(["ta_qa_reporter"], (result) => {
  if (result.ta_qa_reporter) {
    reporterInput.value = result.ta_qa_reporter;
  }
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  const reporter = reporterInput.value.trim();
  const comentario = comentarioInput.value.trim();
  const pasos = pasosInput.value.trim();

  if (!reporter || !comentario) {
    status.textContent = "Nombre y descripcion son obligatorios.";
    return;
  }

  if (!APP_CONFIG.functionUrl.includes("cloudfunctions.net") && !APP_CONFIG.functionUrl.includes("run.app")) {
    status.textContent = "Configura la URL de Firebase Function en config.js";
    return;
  }

  chrome.storage.local.set({ ta_qa_reporter: reporter });

  startBtn.disabled = true;
  status.textContent = "Capturando pantalla...";

  try {
    const response = await chrome.runtime.sendMessage({
      type: "START_QA_REPORT",
      payload: {
        reporter,
        comentario,
        pasos
      }
    });

    if (!response?.ok) {
      throw new Error(response?.error || "No se pudo abrir el editor en la pestana.");
    }

    status.textContent = "Editor abierto en la pestana activa.";
    window.close();
  } catch (error) {
    status.textContent = error.message || "Error inesperado.";
    startBtn.disabled = false;
  }
});
